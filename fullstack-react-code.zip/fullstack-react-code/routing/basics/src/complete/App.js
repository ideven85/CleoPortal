// To see the completed code for the app, check out
// the file `./App-7.js`
import App from './App-7.js';

export default App;
