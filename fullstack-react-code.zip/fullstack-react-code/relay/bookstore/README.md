This project contains a Node API server and a React app generated with create-react-app under `client/`.

To run, first install dependencies for both:

```
$ npm i && cd client && npm i && cd ..
```

Then boot both the server and the client with Foreman:

```
$ npm start
```

