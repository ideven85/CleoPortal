module.exports = {
  Switch: {
    active: {
      backgroundColor: "blue"
    }
  }
};
