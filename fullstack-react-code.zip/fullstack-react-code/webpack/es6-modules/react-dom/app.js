/* eslint-disable import/no-named-as-default-member */
// app.js

import ReactDOM, { render } from './react-dom';

render(); // works / doesn't explode
ReactDOM.render(); // also works / doesn't explode
