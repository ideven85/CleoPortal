// We write the tests for the Modash library in
// this file in the Unit Testing chapter
